﻿namespace Wormhole.Mod
{
    public enum JumpStatus
    {
        Started,
        Ready,
        Perform,
        Succeeded
    }
}