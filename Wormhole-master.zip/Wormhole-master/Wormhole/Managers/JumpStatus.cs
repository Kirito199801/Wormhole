﻿namespace Wormhole.Managers
{
    public enum JumpStatus
    {
        Started,
        Ready,
        Perform,
        Succeeded
    }
}